from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from annonces import views as annonces_views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', annonces_views.accueil, name='accueil'),
    path('logements/', include('annonces.urls')),
    path('users/', include('users.urls')),
    path('reservations/', include('reservations.urls')),  
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .models import Annonce
from reservations.models import Reservation

def accueil(request):
    logements = Annonce.objects.filter(disponible=True)[:6]
    return render(request, 'annonces/accueil.html', {'logements': logements})

def liste_logements(request):
    logements = Annonce.objects.filter(disponible=True)
    
    prix_max = request.GET.get('prix_max')
    if prix_max:
        logements = logements.filter(prix__lte=prix_max)
    
    localisation = request.GET.get('localisation')
    if localisation:
        logements = logements.filter(localisation__icontains=localisation)
    
    return render(request, 'annonces/liste.html', {'logements': logements})

def detail_logement(request, logement_id):
    logement = Annonce.objects.get(id=logement_id)
    return render(request, 'annonces/detail.html', {'logement': logement})

@login_required
def dashboard_proprietaire(request):
    if request.user.type_utilisateur != 'proprietaire':
        return redirect('accueil')
    
    logements = Annonce.objects.filter(proprietaire=request.user)
    reservations = Reservation.objects.filter(logement__in=logements)
    
    return render(request, 'annonces/dashboard_proprietaire.html', {
        'logements': logements,
        'reservations': reservations
    })
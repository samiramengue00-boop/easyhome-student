from django.db import models
from django.conf import settings

class Annonce(models.Model):
    titre = models.CharField(max_length=200)
    description = models.TextField()
    prix = models.IntegerField()
    localisation = models.CharField(max_length=200)
    disponible = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    proprietaire = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, null=True, blank=True)
    image = models.ImageField(upload_to='annonces/', blank=True, null=True)  # ← Champ pour la photo
    
    def __str__(self):
        return self.titre
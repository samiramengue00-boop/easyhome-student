from django.urls import path
from . import views

urlpatterns = [
    path('', views.liste_logements, name='liste_logements'),
    path('<int:logement_id>/', views.detail_logement, name='detail_logement'),
    path('dashboard/', views.dashboard_proprietaire, name='dashboard_proprietaire'),
]
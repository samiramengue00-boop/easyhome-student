from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import HttpResponse
from django.template.loader import render_to_string
from xhtml2pdf import pisa
from io import BytesIO
from annonces.models import Annonce
from .models import Reservation
from datetime import datetime

@login_required
def reserver(request, logement_id):
    logement = get_object_or_404(Annonce, id=logement_id)
    
    if request.user.type_utilisateur != 'etudiant':
        messages.error(request, 'Seuls les étudiants peuvent réserver')
        return redirect('detail_logement', logement_id=logement_id)
    
    if request.method == 'POST':
        date_debut = request.POST['date_debut']
        date_fin = request.POST['date_fin']
        
        # Calcul du montant total
        debut = datetime.strptime(date_debut, '%Y-%m-%d')
        fin = datetime.strptime(date_fin, '%Y-%m-%d')
        jours = (fin - debut).days
        mois = jours / 30
        montant_total = int(mois * logement.prix)
        
        reservation = Reservation.objects.create(
            etudiant=request.user,
            logement=logement,
            date_debut=date_debut,
            date_fin=date_fin,
            statut='en_attente',
            montant_total=montant_total
        )
        
        messages.success(request, f'✅ Réservation confirmée ! Total : {montant_total} FCFA')
        return redirect('telecharger_contrat', reservation_id=reservation.id)
    
    return render(request, 'reservations/reserver.html', {'logement': logement})

@login_required
def mes_reservations(request):
    reservations = Reservation.objects.filter(etudiant=request.user)
    return render(request, 'reservations/mes_reservations.html', {'reservations': reservations})

@login_required
def telecharger_contrat(request, reservation_id):
    reservation = get_object_or_404(Reservation, id=reservation_id, etudiant=request.user)
    
    # Préparer les données pour le contrat
    context = {
        'reservation': reservation,
        'etudiant': reservation.etudiant,
        'logement': reservation.logement,
        'date_aujourdhui': datetime.now().strftime('%d/%m/%Y'),
    }
    
    # Générer le HTML du contrat
    html_string = render_to_string('reservations/contrat.html', context)
    
    # Convertir en PDF avec xhtml2pdf
    result = BytesIO()
    pdf = pisa.pisaDocument(BytesIO(html_string.encode("UTF-8")), result)
    
    if not pdf.err:
        response = HttpResponse(result.getvalue(), content_type='application/pdf')
        response['Content-Disposition'] = f'attachment; filename="contrat_{reservation.id}.pdf"'
        return response
    
    return HttpResponse('Erreur lors de la génération du PDF', status=400)
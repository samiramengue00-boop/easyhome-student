from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate, logout
from django.contrib import messages
from .models import Utilisateur

def inscription(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        password2 = request.POST['password2']
        email = request.POST['email']
        type_utilisateur = request.POST['type_utilisateur']
        telephone = request.POST['telephone']
        
        if password != password2:
            messages.error(request, 'Les mots de passe ne correspondent pas')
            return redirect('inscription')
        
        if Utilisateur.objects.filter(username=username).exists():
            messages.error(request, 'Ce nom d\'utilisateur existe déjà')
            return redirect('inscription')
        
        user = Utilisateur.objects.create_user(
            username=username,
            password=password,
            email=email,
            type_utilisateur=type_utilisateur,
            telephone=telephone
        )
        
        login(request, user)
        return redirect('accueil')
    
    return render(request, 'users/inscription.html')

def connexion(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            login(request, user)
            if user.type_utilisateur == 'proprietaire':
                return redirect('dashboard_proprietaire')
            else:
                return redirect('accueil')
        else:
            messages.error(request, 'Nom d\'utilisateur ou mot de passe incorrect')
    
    return render(request, 'users/connexion.html')

def deconnexion(request):
    logout(request)
    return redirect('accueil')